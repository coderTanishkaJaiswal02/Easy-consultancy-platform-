export const PricingData = [
    [
        {title: 'Basic' ,name: 'Web Design', price: 48},
        {title: 'Standard' ,name: 'Web Design', price: 78},
        {title: 'Premium' ,name: 'Web Design', price: 98},
    ],
    [
        {title: 'Basic' ,name: 'Email Marketing', price: 39},
        {title: 'Standard' ,name: 'Email Marketing', price: 79},
        {title: 'Premium' ,name: 'Email Marketing', price: 99},
    ],
    [
        {title: 'Basic' ,name: 'Graphic Design', price: 36},
        {title: 'Standard' ,name: 'Graphic Design', price: 56},
        {title: 'Premium' ,name: 'Graphic Design', price: 86},
    ],
    [
        {title: 'Basic' ,name: 'Web Development', price: 49},
        {title: 'Standard' ,name: 'Web Development', price: 69},
        {title: 'Premium' ,name: 'Web Development', price: 89},
    ],
    [
        {title: 'Basic' ,name: 'SEO', price: 44},
        {title: 'Standard' ,name: 'SEO', price: 77},
        {title: 'Premium' ,name: 'SEO', price: 88},
    ],
    [
        {title: 'Basic' ,name: 'UI Design', price: 45},
        {title: 'Standard' ,name: 'UI Design', price: 75},
        {title: 'Premium' ,name: 'UI Design', price: 95},
    ]
]