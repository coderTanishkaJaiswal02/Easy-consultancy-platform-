export const SET_USER = "SET USER";
export const SET_ADMIN = "SET ADMIN";
export const SET_SELECTED_SERVICE = "SET SELECTED SERVICE";
