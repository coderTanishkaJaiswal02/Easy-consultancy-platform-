const firebaseConfig = {
    apiKey: "AIzaSyAwR_WCLK2e_x5NK_I2yCdSNnJQC1rPxL8",
    authDomain: "easy-consulting-react.firebaseapp.com",
    projectId: "easy-consulting-react",
    storageBucket: "easy-consulting-react.appspot.com",
    messagingSenderId: "471032014480",
    appId: "1:471032014480:web:cbd7dc3d102ddd71d55a15"
  };export default firebaseConfig;